from tkinter import *

root = Tk()
root.title("ChatTogether")
root.iconbitmap('./Images/ChatTogether.ico')



root.mainloop()